"use strict";

var noiseArray=["chrip"];

noiseArray.push("bark");//add at end of array

noiseArray.unshift("meww");//add at front of array

//noiseArray.push['bhoo bhoo'];

var len=noiseArray.length;

var index=noiseArray.length - 1;//last index of array


var animal={username:"DaffyDuck",
            tagline:"Yipee!!!",
			noises:noiseArray.value};
			
			console.log(animal);